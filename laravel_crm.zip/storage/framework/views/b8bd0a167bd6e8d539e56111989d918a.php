<table class="table table-bordered table-hover">
    <thead class="table-light">
        <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Gender</th>
            <th>Phone</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
    <?php $__empty_1 = true; $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($contact->name); ?></td>
            <td><?php echo e($contact->email); ?></td>
            <td><?php echo e($contact->gender); ?></td>
            <td><?php echo e($contact->phone); ?></td>
            <td>
                <form method="POST" class="deleteForm d-inline" data-id="<?php echo e($contact->id); ?>">
                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                </form>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr><td colspan="5">No contacts found.</td></tr>
    <?php endif; ?>
    </tbody>
</table>
<?php /**PATH D:\Learning\laravel_crm\resources\views/contacts/partials/list.blade.php ENDPATH**/ ?>